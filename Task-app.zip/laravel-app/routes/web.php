<?php

use Illuminate\Support\Facades\Route;

// routes/web.php
use App\Http\Controllers\Mycontroller;

Route::get('/register', [Mycontroller::class, 'showRegisterForm'])->name('register.form');
Route::post('/register', [Mycontroller::class, 'register'])->name('register');

// routes/web.php

use App\Http\Controllers\LoginController;

Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login.form');
Route::post('/login', [LoginController::class, 'login'])->name('login');

use App\Http\Controllers\UserProfileController;

Route::get('/profile', [UserProfileController::class, 'showProfile'])->name('profile.show');
Route::post('/profile/update', [UserProfileController::class, 'updateProfile'])->name('profile.update');
Route::post('/profile/delete', [UserProfileController::class, 'deleteAccount'])->name('profile.delete');

Route::get('/index', [UserProfileController::class, 'index'])->name('index');
Route::resource('task', UserProfileController::class);

use App\Http\Controllers\CategoryController;
Route::get('/categories/create', [CategoryController::class, 'create'])->name('categories.create');
Route::post('/categories', [CategoryController::class, 'store'])->name('categories.store');
Route::resource('categories', CategoryController::class);
Route::resource('categories', CategoryController::class)->only(['create', 'store', 'index', 'destroy']);


Route::get('/logout', [LoginController::class, 'logout'])->name('logout');

Route::get('/delete-category', 'CategoryController@deleteCategoryForm')->name('delete.category.form');
Route::post('/delete-category', 'CategoryController@deleteCategory')->name('delete.category');







Route::get('/', function () {
    return view('index');
});
