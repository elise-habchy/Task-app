<!-- resources/views/register.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width" />
    <link rel="stylesheet" href="<?php echo e(asset('css/css.css')); ?>" />
</head>
<body>
    <div class="container">
        <div class="name">
    <h1>TaskSYN</h1>
    <h3>Your All-in-One Task Management App for Seamless Collaboration, Precision Planning, and Stress-Free Workflow Mastery.</h3>
    </div>
        <div class="center">
            <h2>Register</h2>
            <form method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>
                <div class="txt_field">
                    <input type="text" name="fname" required>
                    <span></span>
                    <label>First Name</label>
                </div>
                <div class="txt_field">
                    <input type="text" name="lname" required>
                    <span></span>
                    <label>Last Name</label>
                </div>
                <div class="txt_field">
                    <input type="text" name="user" required>
                    <span></span>
                    <label>User_Name</label>
                </div>
                <div class="txt_field">
                    <input type="password" name="password" required>
                    <span></span>
                    <label>Password</label>
                </div>
                <input name="submit" type="Submit" value="Sign Up">
                <div class="signup_link">
                    Have an Account? <a href="<?php echo e(route('login')); ?>">Login Here</a>
                </div>
            </form>
            <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
       <?php endif; ?>

    <?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
     <?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/register.blade.php ENDPATH**/ ?>