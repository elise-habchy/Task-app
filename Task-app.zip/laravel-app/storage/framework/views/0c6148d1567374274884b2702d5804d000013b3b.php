<!-- resources/views/user/profile.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <!-- Head content goes here -->
    <title>User Profile</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width" />
    <link rel="stylesheet" href="css/css1.css" />
</head>
<body>
<div class="container">
      <div class="center">
<?php
 $userId = session('id');
$Client = new MongoDB\Client("mongodb://localhost:27017");
$collection = $Client->mongodbproject->users;
$user = $collection->findOne(['username' => $userId]);
// Initialize variables to avoid 'Undefined variable' warning
$fname = $user['fname'] ?? '';
$lname = $user['lname'] ?? '';
$age = $user['age'] ?? '';
$email = $user['email'] ?? '';
$hobbies = $user['hobbies'] ?? '';
$location = $user['location'] ?? '';
$gender = $user['gender'] ?? '';?>


      <h1>Welcome <?php echo $userId?></h1>
      <h2>User Profile</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    <div class="text_field">
        <label for="fname">first name:</label>
        <input type="text" id="fname" name="fname" value="<?php echo htmlspecialchars($fname); ?>"><br><br>
    </div>
    <div class="text_field">
        <label for="lname">last name:</label>
        <input type="text" id="lname" name="lname" value="<?php echo htmlspecialchars($lname); ?>"><br><br>
    </div>
    <div class="text_field">
        <label for="age">age:</label>
        <input type="text" id="age" name="age" value="<?php echo htmlspecialchars($age); ?>"><br><br>
    </div>

    <div class="text_field">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>"><br><br>
</div>

<div class="text_field">
        <label for="hobbies">Hobbies:</label>
        <input type="text" id="hobbies" name="hobbies" value="<?php echo htmlspecialchars($hobbies); ?>"><br><br>
</div>
     <div class="text_field">
        <label for="location">Location:</label>
        <input type="text" id="location" name="location" value="<?php echo htmlspecialchars($location); ?>"><br><br>
        
</div>
<div class="text_field">
        <label for="gender">gender:</label>
        <input type="text" id="gender" name="gender" value="<?php echo htmlspecialchars($gender); ?>"><br><br>
        
</div>
        <input type="submit" name="update" value="Update">
    </form>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <input type="submit" name="delete" value="Delete Account">
    </form>
    <p><a href="loginForm.php">Logout</a></p>


    <!-- Update form action to use the Laravel route -->
    <form action="<?php echo e(route('profile.update')); ?>" method="post">
        <!-- Form fields go here -->

        <input type="submit" name="update" value="Update">
    </form>

    <!-- Delete account form -->
    <form action="<?php echo e(route('profile.delete')); ?>" method="post">
        <input type="submit" name="delete" value="Delete Account">
    </form>

    <p><a href="<?php echo e(route('login')); ?>">Logout</a></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/profile.blade.php ENDPATH**/ ?>