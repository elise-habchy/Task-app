
<!-- resources/views/delete-category-form.blade.php -->

<form action="<?php echo e(route('delete.category')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <label for="category_id">Selected category:</label>
    
    <button type="submit">Delete Category</button>
</form>

<?php if(session('success')): ?>
    <div><?php echo e(session('success')); ?></div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div><?php echo e(session('error')); ?></div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/categories/delete.blade.php ENDPATH**/ ?>