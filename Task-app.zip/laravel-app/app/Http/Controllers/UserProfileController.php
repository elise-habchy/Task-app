<?php
namespace App\Http\Controllers;

use App\Models\Task;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Category;
use Illuminate\Support\Facades\Auth;
class UserProfileController extends Controller
{
    /**
     *
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
  
      $user = session("username");
      $tasks = Task::where('user_name', $user)->orderBy('id', 'desc')->get();
        return view('index', compact('tasks'));
        }
    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $statuses = [
            [
                'label' => 'Todo',
                'value' => 'Todo',
            ],
            [
                'label' => 'Done',
                'value' => 'Done',
            ]
        ];
        $categories = Category::all();
        return view('create', compact('statuses','categories'));
    }
 

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'category' => 'exists:categories,id',
        ]);
        $username = session('username');
        $task = new Task();
        $task->user_name=$username;
        $task->title = $request->title;
        $task->description = $request->description;
        $task->status = $request->status;
        $task->category_id = $request->category;
        $task->save();
        return redirect()->route('index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
  
    public function showProfile()
    {
            $user=Auth::user();
           
            $username = session('username');
            $user = User::find($username);
            if ($user) {
                $tasks=$user->tasks()->orderBy('id','desc')->get();
            }
            return view('layout', compact('user'));
        }
    

    /**
     * 
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $task = Task::findOrFail($id);
        $statuses = [
            [
                'label' => 'Todo',
                'value' => 'Todo',
            ],
            [
                'label' => 'Done',
                'value' => 'Done',
            ]
        ];
        $categories = Category::all();
        return view('edit', compact('statuses', 'task','categories'));
    }

    /**
     * 
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $task = Task::findOrFail($id);
        $request->validate([
            'title' => 'required',
            'category_id' => 'required|exists:categories,id', 
        ]);

        $task->title = $request->title;
        $task->description = $request->description;
        $task->status = $request->status;
        $task->category_id = $request->category_id;
        $task->save();
        return redirect()->route('index');
    }

    /** 
     *      
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $task = Task::findOrFail($id);
        $task->delete();
        return redirect()->route('index');
    }
}
