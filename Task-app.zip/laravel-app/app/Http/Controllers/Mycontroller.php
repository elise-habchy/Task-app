<?php
/*
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use MongoDB\Client as MongoClient;

class Mycontroller extends Controller
{
    public function showRegisterForm()
    {
        return view('register');
    }

    public function register(Request $request)
    {
        $mongoClient = new MongoClient("mongodb://localhost:27017");
        $collection = $mongoClient->mongodbproject->users;

        $fname = $request->input('fname');
        $lname = $request->input('lname');
        $user = $request->input('user');
        $password = $request->input('password');

        // Check if username exists
        $existingUser = $collection->findOne(['username' => $user]);

        if ($existingUser) {
            return redirect()->back()->with('error', 'Username already exists. Please choose a different username.');
        } else {
            // Insert new user
            $newUser = [
                'fname' => $fname,
                'lname' => $lname,
                'username' => $user,
                'password' => $password,
            ];

            $insertResult = $collection->insertOne($newUser);

            if ($insertResult->getInsertedCount() > 0) {
                return redirect()->back()->with('success', 'User registered successfully!');
            } else {
                return redirect()->back()->with('error', 'User registration failed.');
            }
        }
    }
}
*/
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User; // Assuming you have a User model

class MyController extends Controller
{
    public function showRegisterForm()
    {
        return view('register');
    }

    public function register(Request $request)
    {
        $username = $request->input('user');

        // Check if username exists
        $existingUser = User::where('username', $username)->first();

        if ($existingUser) {
            return redirect()->back()->with('error', 'Username already exists. Please choose a different username.');
        } else {
            // Insert new user
            $newUser = new User;
            $newUser->fname = $request->input('fname');
            $newUser->lname = $request->input('lname');
            $newUser->username = $username;
            $newUser->password = $request->input('password');

            if ($newUser->save()) {
                return redirect()->back()->with('success', 'User registered successfully!');
            } else {
                return redirect()->back()->with('error', 'User registration failed.');
            }
        }
}
}

?>




