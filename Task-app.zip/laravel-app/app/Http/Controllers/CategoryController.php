<?php

namespace App\Http\Controllers;
use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    
        public function create()
        {
            return view('categories.create');
        }
    
        public function store(Request $request)
        {
            $request->validate([
                'name' => 'required|unique:categories',
            ]);
    
            $category = new Category(['name' => $request->input('name')]);
             $category->save();
    
            return redirect()->route('index')->with('success', 'Category created successfully.');
        }

      
       public function deleteCategoryForm()
       {
           $categories = Category::all();
           return view('delete-category-form', compact('categories'));
       }
       
       public function deleteCategory(Request $request)
       {
           $categoryId = $request->input('category_id');
           $category = Category::find($categoryId);
   
           if ($category) {
               $category->delete();
               return redirect()->route('delete.category.form')->with('success', 'Category deleted successfully.');
           }
   
           return redirect()->route('delete.category.form')->with('error', 'Category not found.');
       }

        
        public function show(Category $category)
        {
            return view('categories.delete', compact('category'));
        }
        public function index()
    {
        $categories = Category::all();
        return view('categories.create', compact('categories'));
    }
  
}