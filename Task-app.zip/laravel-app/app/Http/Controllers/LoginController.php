<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User; 

class LoginController extends Controller
{
    public function showLoginForm()
    {
        return view('login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'username' => 'required',
            'password' => 'required',
        ]);

        $username = $request->input('username');
        $password = $request->input('password');

        // Find user by username and password
        $user = User::where('username', $username)->where('password', $password)->first();
        
        if ($user) {
            session()->put('loggedin', true);
            session()->put('id', $user->id);
            session()->put('username',$user->username);

            return redirect()->route('profile.show')->with('message', 'Login successful! Welcome, ' . $user->username);
        } else {
            return redirect()->back()->with('error', 'Invalid username or password!');
        }
    }
    public function logout()
{
   // Auth::logout();
    return redirect()->route('login')->with('success', 'Successfully logged out.');
}
}

