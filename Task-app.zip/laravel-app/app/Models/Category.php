<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;
    protected $fillable = ['name'];

    public function tasks()
    {
        return $this->hasMany(Task::class);
    }

    public function create()
{
    
    return view('categories.create');
}

public function store(Request $request)
{
    $request->validate([
        'name' => 'required|unique:categories',
    ]);


}
public function deleteCategory()
{
    return $this->delete();
}
}