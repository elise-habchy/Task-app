<!-- resources/views/categories/create.blade.php -->


@extends('layout')

@section('main-content')
    <div>
        <div class="float-start">
            <h4 class="pb-3">Create Category</h4>
        </div>
</br>
        <form action="{{ route('categories.store') }}" method="POST">
            @csrf
            <div class="mb-3">
                <label for="name" >Category Name</label>
                <input type="text" class="form-control" id="name" name="name">
            </div>

            <button type="submit" class="btn btn-success">
                <i class="fa fa-check"></i> Save Category
            </button>
        </form>
    </div>
@endsection
