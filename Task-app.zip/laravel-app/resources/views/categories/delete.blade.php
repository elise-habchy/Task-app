

<form action="{{ route('delete.category') }}" method="post">
    @csrf
    <label for="category_id">Selected category:</label>
    
    <button type="submit">Delete Category</button>
</form>

@if(session('success'))
    <div>{{ session('success') }}</div>
@endif

@if(session('error'))
    <div>{{ session('error') }}</div>
@endif