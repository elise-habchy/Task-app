<!-- resources/views/register.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width" />
    <link rel="stylesheet" href="{{ asset('css/css.css') }}" />
</head>
<body>
    <div class="container">
        <div class="name">
    <h1>TaskSYN</h1>
    <h3>Your All-in-One Task Management App for Seamless Collaboration, Precision Planning, and Stress-Free Workflow Mastery.</h3>
    </div>
        <div class="center">
            <h2>Register</h2>
            <form method="POST" action="{{ route('register') }}">
                @csrf
                <div class="txt_field">
                    <input type="text" name="fname" required>
                    <span></span>
                    <label>First Name</label>
                </div>
                <div class="txt_field">
                    <input type="text" name="lname" required>
                    <span></span>
                    <label>Last Name</label>
                </div>
                <div class="txt_field">
                    <input type="text" name="user" required>
                    <span></span>
                    <label>User_Name</label>
                </div>
                <div class="txt_field">
                    <input type="password" name="password" required>
                    <span></span>
                    <label>Password</label>
                </div>
                <input name="submit" type="Submit" value="Sign Up">
                <div class="signup_link">
                    Have an Account? <a href="{{ route('login') }}">Login Here</a>
                </div>
            </form>
            @if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
       @endif

    @if(session('error'))
    <div class="alert alert-danger">
        {{ session('error') }}
    </div>
     @endif
        </div>
    </div>
</body>
</html>
